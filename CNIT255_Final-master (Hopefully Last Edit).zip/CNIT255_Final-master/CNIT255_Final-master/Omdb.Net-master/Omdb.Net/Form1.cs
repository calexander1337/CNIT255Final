﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Omdb.Net.RequestBuilder;
namespace Omdb.Net
{
    public partial class Form1 : Form
    {
        private static Omdb.Net.RequestBuilder.OmdbSearchRequestBuilder target;
        Actor a;
        Movie m;
        Director d;
        IMDB i;
        Producer p;
        static void Main()
        {
            Application.Run(new Form1());

        }
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtTitle.Clear();
            txtAFirstName.Clear();
            txtALastName.Clear();
            txtIMDB.Clear();
            txtRating.Clear();
            txtMovies.Clear();
            txtVotes.Clear();
            txtYear.Clear();
            txtDFirstName.Clear();
            txtDLastName.Clear();
            txtDirectedMovies.Clear();
            txtGenre.Clear();
            txtIMDB.Clear();
            txtMovies.Clear();
            txtMoviesProduced.Clear();
            txtPFirstName.Clear();
            txtPLastName.Clear();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
             //display movie info from IMDB
            var target = Omdb.Net.RequestBuilder.OmdbSearchRequestBuilder.SearchTitle(txtTitle.Text);
            var response = target.MakeRequest();

            var result = Task.Run(() => response).Result;
        }

        private void btnSave_Click(object sender, System.EventArgs e)
        {
            a = new Actor();
            m = new Movie();
            d = new Director();
            i = new IMDB();
            p = new Producer();
            a.setFirstName(txtAFirstName.Text);
            a.setLastName(txtALastName.Text);
            a.setMovies(txtMovies.Text);
            i.setIMDBRating(txtIMDB.Text);
            i.setVotes(txtVotes.Text);
            m.setRating(txtRating.Text);
            m.setTitle(txtTitle.Text);
            m.setGenre(txtGenre.Text);
            m.setYear(txtYear.Text);
            d.setFirstName(txtDFirstName.Text);
            d.setLastName(txtDLastName.Text);
            d.setMoviesDirected(txtDirectedMovies.Text);
            p.setFirstName(txtPFirstName.Text);
            p.setLastName(txtPLastName.Text);
            p.SetMoviesProduced(txtMoviesProduced.Text);

        }

        private void btnRestore_Click(object sender, System.EventArgs e)
        {
            if (null == a || null == i || null == p || null == d || null == m)
            {
                return;
            }

            txtAFirstName.Text = a.getFirstName();
            txtALastName.Text = a.getLastName();
            txtMovies.Text = a.getMovies();
            txtIMDB.Text = i.getIMDBRating();
            txtVotes.Text = i.getVotes();
            txtRating.Text = m.getRating();
            txtTitle.Text = m.getTitle();
            txtGenre.Text = m.getGenre();
            txtYear.Text = m.getYear();
            txtDFirstName.Text = d.getFirstName();
            txtDLastName.Text = d.getLastName();
            txtDirectedMovies.Text = d.getMoviesDirected();
            txtPFirstName.Text = p.getFirstName();
            txtPLastName.Text = p.getLastName();
            txtMoviesProduced = p.GetMoviesProduced();
        }


    }
}
