﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omdb.Net
{
    class Actor : Person
    {
        private string Movies;
        public string getMovies()
        {
            return this.Movies;
        }
        public void setMovies(string theseMovies)
        {
            Movies = theseMovies;
        }
    }
}
