﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omdb.Net
{
    class Person
    {
        private string FirstName;
        public string getFirstName()
        {
            return FirstName;
        }
        public void setFirstName(string Value)
        {
            this.FirstName = Value;
        }
        private string LastName;
        public string getLastName()
        {
            return LastName;
        }
        public void setLastName(string Value)
        {
            this.LastName = Value;
        }
    }
}
