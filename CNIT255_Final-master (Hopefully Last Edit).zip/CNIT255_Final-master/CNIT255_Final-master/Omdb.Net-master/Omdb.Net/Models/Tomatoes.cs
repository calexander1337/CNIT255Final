﻿
namespace Omdb.Net.Models
{
    public class Tomatoes
    {
        public string tomatoMeter { get; set; }
        public string tomatoImage { get; set; }
        public string tomatoRating { get; set; }
        public string tomatoReviews { get; set; }
        public string tomatoFresh { get; set; }
        public string tomatoRotten { get; set; }
        public string tomatoConsensus { get; set; }
        public string tomatoUserMeter { get; set; }
        public string tomatoUserRating { get; set; }
        public string tomatoUserReviews { get; set; }
        public string DVD { get; set; }
        public string BoxOffice { get; set; }
        public string Production { get; set; }
        public string Website { get; set; }
    }
}
