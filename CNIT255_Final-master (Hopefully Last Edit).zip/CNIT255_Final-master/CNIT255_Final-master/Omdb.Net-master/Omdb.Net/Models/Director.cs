﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omdb.Net
{
    class Director : Person
    {
        private string MoviesDirected;
        public string getMoviesDirected()
        {
            return MoviesDirected;
        }
        public void setMoviesDirected(string Value)
        {
            this.MoviesDirected = Value;
        }
    }
}
