﻿
namespace Omdb.Net.Models
{
    public enum PlotLenthType
    {
        Short = 0,
        Full = 1
    }
}
