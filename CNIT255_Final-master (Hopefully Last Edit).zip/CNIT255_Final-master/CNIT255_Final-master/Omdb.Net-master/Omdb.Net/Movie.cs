﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omdb.Net
{
    class Movie
    {
        string Rating;
        public string getRating()
        {
            return Rating;
        }
        public void setRating(string Value)
        {
            this.Rating = Value;
        }
        string Title;
        public string getTitle()
        {
            return Title;
        }
        public void setTitle(string Value)
        {
            this.Title = Value;
        }
        string Genre;
        public string getGenre()
        {
            return Genre;
        }
        public void setGenre(string Value)
        {
            this.Genre = Value;
        }
        string Year;
        public string getYear()
        {
            return Year;
        }
        public void setYear(string Value)
        {
            this.Year = Value;
        }
    }
}
