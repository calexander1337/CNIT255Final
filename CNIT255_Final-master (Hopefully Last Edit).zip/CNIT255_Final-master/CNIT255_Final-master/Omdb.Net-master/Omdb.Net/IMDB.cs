﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omdb.Net
{
    class IMDB
    {
        string IMDBRating;
        public string getIMDBRating()
        {
            return IMDBRating;
        }
        public void setIMDBRating(string Value)
        {
            this.IMDBRating = Value;
        }
        string Votes;
        public string getVotes()
        {
            return Votes;
        }
        public void setVotes(string Value)
        {
            this.Votes = Value;
        }
    }
}
