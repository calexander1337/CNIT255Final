﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omdb.Net
{
    class Producer : Person
    {
        string MoviesProduced;
        public string GetMoviesProduced()
        {
            return MoviesProduced;
        }
        public void SetMoviesProduced(string Value)
        {
            this.MoviesProduced = Value;
        }
    }
}
