Omdb.Net
========

Omdb.Net is a .NET class wrapper for the Omdb API. It saves the hassle of having to set up HTTP Requests to it.
Omdb is in no way affiliated with the work done by Brian Fritz and Omdb. However, donations there I'm sure would be welcome  http://www.omdbapi.com/.

- Project website https://github.com/MartinMilsom/Omdb.Net
